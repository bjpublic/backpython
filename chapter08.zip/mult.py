def multiply_by_two(x): 
    return x * 2

def test_multiply_by_two():
	assert multiply_by_two(4) == 8
