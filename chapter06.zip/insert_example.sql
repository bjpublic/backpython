INSERT INTO users ( 
    id,
    name, 
    age, 
    gender
) VALUES ( 
    1,
    "송은우",
    35, 
    "남자"
), ( 
    2,
    "Robert Kelly",
    28,
    "남자"
), ( 
    3,
    "Cristiano Ronaldo",
    33,
    "남자" 
)                
