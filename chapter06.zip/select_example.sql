SELECT 
    id,
    name, 
    age, 
    gender
FROM users
