SELECT 
    id,
    name, 
    age, 
    gender
FROM users
WHERE name = "송은우"
