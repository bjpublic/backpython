UPDATE users SET age = 25 WHERE name = "아이유"
